﻿namespace API.Services
{
    public interface IUserService
    {
        string GetMyName();
    }
}
